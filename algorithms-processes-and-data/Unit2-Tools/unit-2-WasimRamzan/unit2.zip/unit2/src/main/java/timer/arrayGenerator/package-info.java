/**
 * Time execution of various array generators.
 *
 * @author Hugh Osborne
 * @version September 2020
 */
package timer.arrayGenerator;