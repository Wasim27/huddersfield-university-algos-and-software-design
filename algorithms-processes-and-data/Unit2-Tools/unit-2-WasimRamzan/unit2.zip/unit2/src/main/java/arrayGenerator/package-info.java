/**
 * Tools for generator arrays with various properties.
 *
 * @author Hugh Osborne
 * @version September 2020
 */
package arrayGenerator;