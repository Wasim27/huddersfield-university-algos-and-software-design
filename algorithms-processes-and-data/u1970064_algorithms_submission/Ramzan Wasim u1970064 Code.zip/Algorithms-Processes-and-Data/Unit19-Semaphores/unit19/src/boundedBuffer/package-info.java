/**
 * An implementation of bounded buffers using semaphores to protect buffer access.
 */
package boundedBuffer;