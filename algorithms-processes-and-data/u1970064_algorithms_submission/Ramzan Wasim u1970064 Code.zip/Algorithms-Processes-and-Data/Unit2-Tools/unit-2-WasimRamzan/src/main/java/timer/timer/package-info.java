/**
 * Define default methods for timers.
 *
 * @author Hugh Osborne
 * @version Spetember 2020
 */
package timer.timer;