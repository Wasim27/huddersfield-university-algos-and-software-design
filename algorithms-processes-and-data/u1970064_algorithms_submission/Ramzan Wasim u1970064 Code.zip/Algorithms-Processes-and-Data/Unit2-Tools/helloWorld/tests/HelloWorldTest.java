import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class HelloWorldTest {
    @Test
    public void passTest(){
    }

    @Test
    public void failTest() {
        fail();
    }

    @Test
    public void test(){}

}