/**
 * A demo class.
 *
 * @author Wasim Ramzan
 * @version September 2020
 */

public class HelloWorld {

    /**
     * A demo method.
     * @param args command line arguments (not used)
     */

    public static void main(String[] args) {
        System.out.println("Hello world");
    }
}
