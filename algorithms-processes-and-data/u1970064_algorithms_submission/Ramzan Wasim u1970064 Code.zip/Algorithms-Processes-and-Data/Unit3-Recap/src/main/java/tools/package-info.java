/**
 * Provides tools for the other packages (currently just Print for controlled printing of arrays, and printing of
 * ordinal numbers).
 *
 * @author Hugh Osborne
 * @version September 2020
 */

package tools;