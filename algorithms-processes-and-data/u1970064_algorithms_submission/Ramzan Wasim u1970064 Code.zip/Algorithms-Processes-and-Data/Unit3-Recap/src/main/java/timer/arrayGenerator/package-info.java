/**
 * Times array generators.
 *
 * @author Hugh Osborne
 * @version September 2020
 */

package timer.arrayGenerator;