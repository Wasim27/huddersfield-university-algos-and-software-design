/**
 * Timers provide a facility for timing execution of defined methods from classes for varying "sizes of problem".
 *
 * @author Hugh Osborne
 * @version September 2019
 */

package timer.timer;