/**
 * Times searchers.
 *
 * @author Hugh Osborne
 * @version September 2020
 */

package timer.searcher;