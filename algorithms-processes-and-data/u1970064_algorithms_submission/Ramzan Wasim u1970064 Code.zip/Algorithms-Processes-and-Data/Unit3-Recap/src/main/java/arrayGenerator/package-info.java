/**
 * ArrayGenerators are objects that generate arrays of integers.
 *
 * @author Hugh Osborne
 * @version September 2020
 */

package arrayGenerator;
