/**
 * Demonstration package using monitors to implement a simple car park system.
 */

package carpark;