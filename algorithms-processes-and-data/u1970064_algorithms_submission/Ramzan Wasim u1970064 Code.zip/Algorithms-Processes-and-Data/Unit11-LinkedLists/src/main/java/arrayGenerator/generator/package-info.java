/**
 * Defines Array Generators and provides some implementations thereof.
 *
 * @author HughOsborne
 * @version October 2019
 */
package arrayGenerator.generator;